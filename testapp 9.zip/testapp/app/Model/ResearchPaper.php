<?php
App::uses('AppModel', 'Model');
/**
 * ResearchPaper Model
 *
 */
class ResearchPaper extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'title';

}
