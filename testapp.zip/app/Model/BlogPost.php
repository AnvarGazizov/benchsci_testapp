<?php
App::uses('AppModel', 'Model');
/**
 * BlogPost Model
 *
 */
class BlogPost extends AppModel {

}
